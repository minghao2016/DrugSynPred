# Internal functions for syngen package

plothm. <- function(x, color=c("cornflowerblue","salmon"), gama=1, grid=T, scmax=0, ...) {
    if (scmax==0) scmax <- max(abs(x), na.rm=T)
    pos <- which(abs(x) > scmax)
    if (length(pos)>0) x[pos] <- scmax*sign(x[pos])
    x <- abs(x/scmax)^gama*sign(x)
    x <- filterRowMatrix(x, nrow(x):1)
    color <- rgb2hsv(col2rgb(color))
    satval <- color[3,]
    color <- color[1,]
    x1 <- x
    x1[is.na(x1)] <- 0
    coli <- hsv(ifelse(x1<0, color[1], color[2]), abs(x1), 1)
    coli[is.na(x)] <- hsv(0, 0, .5)
    image(1:ncol(x), 1:nrow(x), t(matrix(1:(ncol(x)*nrow(x)), nrow(x), ncol(x))), col=coli, ylab="", xlab="", axes=F, ...)
    box()
    if (grid) grid(ncol(x), nrow(x), col="black", lty=1)
}

plothm <- function(x, color=c("cornflowerblue","salmon"), gama=1, cex=1, grid=T, scale=F, scmax=0, ...) {
    if (scale>0) {
        if (scale==1) ff <- 6/(nrow(x)+5)
        else ff <- scale
        pari <- par("mai")
        layout(matrix(1:2, 2, 1), heights=c(1-ff, ff))
        if (round(sum(pari-c(1.02, .82, .82, .42)), 2)==0) pari <- c(.2, .2, 1.2, 1.2)
        par(mai=pari)
        plothm.(x, color=color, gama=gama, scmax=scmax, ...)
        axis(4, nrow(x):1, rownames(x), tick=F, line=0, las=2, adj=0, cex.axis=cex)
        axis(3, 1:ncol(x), colnames(x), tick=F, line=0, las=2, adj=0, cex.axis=cex)
        ra <- seq(-1, 1, length=100)
        ra <- sign(ra)*abs(ra)^gama
        color <- rgb2hsv(col2rgb(color))
        satval <- color[3, ]
        color <- color[1, ]
        coli <- hsv(ifelse(ra < 0, color[1], color[2]), abs(ra), 1)
        par(mai=pari*c(0, 1, 0, 3)+c(.5, 0, .1, 0))
        image(1:length(ra), 1, matrix(1:length(ra), length(ra), 1), col = coli, ylab = "", xlab = "", axes = F)
        if (scmax==0) scmax <- max(abs(x), na.rm=T)
        axis(1, seq(1, length(ra), length=5), round(seq(-scmax, scmax, length=5), 1), cex.axis=cex)
    }
    else plothm.(x=x, color=color, gama=gama, grid=grid, scmax=scmax, ...)
}

cortest <- function(r, n, alternative="two.sided") {
    z <- log((1+r)/(1-r))/2*sqrt(n-3)
    switch(match.arg(alternative, c("two.sided", "less", "greater")),
           two.sided={p <- pnorm(abs(z), lower.tail=F)*2},
           less={p <- pnorm(z, lower.tail=T)},
           greater={p <- pnorm(z, lower.tail=F)})
    return(list(z=z, p.value=p))
}

signatureDistance <- function(dset1, dset2=NULL, nn=NULL, groups=NULL, scale.=TRUE, two.tails=TRUE, ws=2) {
    if (is.null(nn)) {
        if (ws>0) nn <- nrow(dset1)
        else nn <- nrow(dset1)/10
    }
    nn <- round(nn/2)
    d1 <- dset1
    if (is.null(dset2)) {
        if (ws==0 & nrow(d1)<(nn*3)) stop("Error, insufficient number of features to perform analysis", call.=FALSE)
        if (!is.null(groups)) d1 <- scaleGroups(dset1, groups)
        else if (scale.) d1 <- t(scale(t(dset1)))
        if (two.tails) {
            reg <- lapply(1:ncol(d1), function(i, d1, nn, ws) {
                orden <- order(d1[, i])
                tmp <- d1[orden[c(1:nn, (nrow(d1)-nn+1):nrow(d1))], i]
                return(abs(tmp)^ws*sign(tmp))
            }, d1=d1, nn=nn, ws)
        }
        else {
            reg <- lapply(1:ncol(d1), function(i, d1, nn, ws) {
                orden <- order(abs(d1[, i]), decreasing=TRUE)
                tmp <- d1[orden[1:(2*nn)], i]
                return(abs(tmp)^ws)
            }, d1=d1, nn=nn, ws=ws)
        }
        names(reg) <- colnames(d1)
        if (ws==0) {
            d1 <- apply(d1, 2, rank)/(nrow(d1)+1)*2-1
            if (!two.tails) {
                d1 <- abs(d1)*2-1
                d1[d1==(-1)] <- 1-(1/nrow(d1))
            }
            d1 <- qnorm(d1/2+.5)
        }
        genes <- unique(unlist(lapply(reg, names), use.names=FALSE))
        d1 <- t(d1[match(genes, rownames(d1)), ])
        reg <- sapply(reg, function(x, genes) x[match(genes, names(x))], genes=genes)
        reg[is.na(reg)] <- 0
        ww <- colSums(abs(reg))
        reg <- t(t(reg)/ww)
        es <- (d1 %*% reg)*sqrt(ww)
        offdiag <- rowMeans(cbind(es[lower.tri(es)], t(es)[lower.tri(es)]))
        es[lower.tri(es)] <- offdiag
        es <- t(es)
        es[lower.tri(es)] <- offdiag
        class(es) <- "signatureDistance"
        return(es)
    }
    d2 <- dset2
    genes <- rownames(d1)[rownames(d1) %in% rownames(d2)]
    if (ws==0 & length(genes)<(nn*3)) stop("Error, insufficient number of common features to perform analysis", call.=FALSE)
    d1 <- filterRowMatrix(d1, match(genes, rownames(d1)))
    d2 <- filterRowMatrix(d2, match(genes, rownames(d2)))
    if (!is.null(groups)) {
        if (length(groups)==2) {
            d1 <- scaleGroups(dset1, groups[[1]])
            d2 <- scaleGroups(dset2, groups[[2]])
        }
        else {
            d1 <- t(scale(t(dset1)))
            d2 <- t(scale(t(dset2)))
            warning("Not using groups...Expecting a 2 elements list for groups when dset2 is defined", call.=FALSE)
        }
    }
    else if (scale.) {
        d1 <- t(scale(t(dset1)))
        d2 <- t(scale(t(dset2)))
    }
    if (two.tails) {
        reg1 <- lapply(1:ncol(d1), function(i, d1, nn, ws) {
            orden <- order(d1[, i])
            tmp <- d1[orden[c(1:nn, (nrow(d1)-nn+1):nrow(d1))], i]
            return(abs(tmp)^ws*sign(tmp))
        }, d1=d1, nn=nn, ws=ws)
        reg2 <- lapply(1:ncol(d2), function(i, d1, nn, ws) {
            orden <- order(d1[, i])
            tmp <- d1[orden[c(1:nn, (nrow(d1)-nn+1):nrow(d1))], i]
            return(abs(tmp)^ws*sign(tmp))
        }, d1=d2, nn=nn, ws=ws)
    }
    else {
        reg1 <- lapply(1:ncol(d1), function(i, d1, nn, ws) {
            orden <- order(d1[, i], decreasing=TRUE)
            tmp <- d1[orden[1:(2*nn)], i]
            return(abs(tmp)^ws)
        }, d1=d1, nn=nn, ws=ws)
        reg2 <- lapply(1:ncol(d2), function(i, d1, nn, ws) {
            orden <- order(d1[, i], decreasing=TRUE)
            tmp <- d1[orden[1:(2*nn)], i]
            return(abs(tmp)^ws)
        }, d1=d2, nn=nn, ws=ws)
    }
    names(reg1) <- colnames(d1)
    names(reg2) <- colnames(d2)
    if (ws==0) {
        d1 <- apply(d1, 2, rank)/(nrow(d1)+1)*2-1
        d2 <- apply(d2, 2, rank)/(nrow(d2)+1)*2-1
        if (!two.tails) {
            d1 <- abs(d1)*2-1
            d1[d1==(-1)] <- 1-(1/nrow(d1))
            d2 <- abs(d2)*2-1
            d2[d2==(-1)] <- 1-(1/nrow(d2))
        }
        d1 <- qnorm(d1/2+.5)
        d2 <- qnorm(d2/2+.5)
    }
    genes <- unique(unlist(lapply(reg1, names), use.names=FALSE))
    d2 <- t(filterRowMatrix(d2, match(genes, rownames(d2))))
    reg1 <- sapply(reg1, function(x, genes) x[match(genes, names(x))], genes=genes)
    reg1[is.na(reg1)] <- 0
    genes <- unique(unlist(lapply(reg2, names), use.names=FALSE))
    d1 <- t(filterRowMatrix(d1, match(genes, rownames(d1))))
    reg2 <- sapply(reg2, function(x, genes) x[match(genes, names(x))], genes=genes)
    reg2[is.na(reg2)] <- 0
    ww1 <- colSums(abs(reg1))
    ww2 <- colSums(abs(reg2))
    reg1 <- t(t(reg1)/ww1)
    reg2 <- t(t(reg2)/ww2)
    es <- ((d1 %*% reg2)*sqrt(ww1)+t(d2 %*% reg1)*sqrt(ww2))/2
    class(es) <- "signatureDistance"
    return(es)
}

scaleGroups <- function(x, groups) {
    colnames(x) <- groups
    res <- sapply(unique(groups), function(x, dset) {
        x1 <- dset[, colnames(dset)==x]
        x2 <- dset[, colnames(dset)!=x]
        if (is.null(ncol(x1)) | is.null(ncol(x2))) tmp <- rowTtest(x1-x2, alternative="two.sided")
        else tmp <- rowTtest(x1, x2, alternative="two.sided")
        return((qnorm(tmp$p.value/2, lower.tail=FALSE)*sign(tmp$statistic))[, 1])
    }, dset=x)
    mm <- max(abs(res)[is.finite(res)])
    ipos <- which(is.infinite(res))
    res[ipos] <- mm+runif(length(ipos), 0, 10)
    colnames(res) <- unique(groups)
    return(res)
}

as.dist.signatureDistance <- function(m, diag=FALSE, upper=FALSE) {
    m <- scale(m)
    class(m) <- "matrix"
    return(as.dist(1-m))
}

scale.signatureDistance <- function(x, center=TRUE, scale=TRUE) {
    if (ncol(x) != nrow(x)) return(x/max(abs(x)))
    mm <- (matrix(diag(x), nrow(x), ncol(x)) + matrix(diag(x), nrow(x), ncol(x), byrow=TRUE))/2
    return(x/mm)
}

filterRowMatrix <- function(x, filter) {
    if (is.logical(filter)) largo <- length(which(filter))
    else largo <- length(filter)
    matrix(x[filter, ], largo, ncol(x), dimnames=list(rownames(x)[filter], colnames(x)))
}

filterColMatrix <- function(x, filter) t(filterRowMatrix(t(x), filter))

