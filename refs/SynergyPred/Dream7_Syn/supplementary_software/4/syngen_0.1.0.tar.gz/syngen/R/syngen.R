#' Prediction of compounds inducing specific phenotypic transitions
#'
#' This function predicts single agent and 2-way combinations that can induce specific phenotypic transitions
#'
#' @param phsig Phenotype signature as a named vector or matrix
#' @param drugsig Compounds response signatures in a matrix format, with samples in columns and genes in rows
#' @param nn Number indicating the number of genes to use for the reciprocal enrichment analysis using \code{signatureDistance}
#' @param ws Number indicating the weighting score for the \code{signatureDistance} function
#' @param absolute Logical, whether absolute enrichment analysis between phenotype and compounds signatures should be used
#' @param cutoff Number indicating either the p-value cutoff for considering a compound significantly enriched on the phenotype, or an integrer indicating the number of top-enriched compounds to use for the synergy estimation
#' @param method Character string indicating the method of choice for synergy estimation, either orthogonal or complemental
#' @param scc Optional number indicating the scaling factor for the orthogonality score
#' @param phdistance Logical, whether the distance between the phenotype and compounds signature should be computed
#' @param score Numeric vector indicating the exponent for the self-weighting when integrating the signatures and the exponent for the NES-based weighting of the contribution from each compound
#' @param ints Number indicating the exponent score for weighting the similarity matrix when multiple datasets are used for the orthogonality computation
#' @return S3 object of class phenotypeSynergy with methods plot, print and head. Format: list of 6 elements. phdrugs: vector of drugs antagonizing the phenotype with score as -log10(p); orthomatrix: matrix of drug orthogonality containing the reciprocal enrichment p-value; symatrix: matrix of synergy scores; orthodrugs: vector of drug pairs with orthogonality score; sydrugs: vector of synergy scores; param: list of used parameters.
#' @examples
#' data(dream6h)
#' sgr <- phenoDrug(toxicly3, dream6h, nn=50, cutoff=ncol(dream6h), method="complemental", score=0)
#' print(sgr)
#' plot(sgr)
#' @export

phenoDrug <- function(phsig, drugsig, nn=NULL, ws=2, absolute=FALSE, cutoff=.01, method=c("orthogonal", "complemental"), scc=NULL, phdistance=TRUE, score=1, ints=0) {
    method <- match.arg(method)
    if (length(score)==1) score <- rep(score, 2)
    if (is.null(ncol(phsig))) {
        phsig <- matrix(phsig, length(phsig), 2, dimnames=list(names(phsig), NULL))
    }
    if (is.null(nn) & ws==0) {
        nn <- round(length(which(rownames(phsig) %in% rownames(drugsig)))/10)
    }
    ds <- phsig
    if (!is.list(drugsig)) drugsig <- list(drugsig)
    drugs <- unique(unlist(lapply(drugsig, colnames), use.names=F))
    genes <- table(unlist(lapply(drugsig, rownames), use.names=F))
    genes <- names(genes)[genes==length(drugsig) & names(genes) %in% rownames(phsig)]
    drugsig <- lapply(drugsig, function(x, drugs, genes) {
        x[match(genes, rownames(x)), ][, match(drugs, colnames(x))]
    }, drugs=drugs, genes=genes) 
    if (phdistance) {
        tmp <- sapply(drugsig, function(x, phsig, absolute, nn, ws) {
            scale(signatureDistance(cbind(-phsig, x), nn=nn, scale.=F, two.tails=!absolute, ws=ws))[, -1][1, ]
        }, phsig=phsig[, 1], nn=nn, absolute=absolute, ws=ws)
        ds <- rowMeans(cortest(tmp, length(genes), alternative="greater")$z)
    }
    if (is.null(nrow(ds))) {
        ds <- matrix(ds, length(ds), 2, dimnames=list(names(ds), NULL))
    }
    dnes <- ds
    ds1 <- max(abs(ds))
    ds <- pnorm(ds, lower.tail=F)
    if (cutoff<1) cutoff <- colSums(ds<cutoff)
    if (cutoff[1]>1) {
        if (length(cutoff)==1) cutoff <- rep(cutoff, 2)
        dsf <- lapply(1:2, function(i, ds, cutoff) {
            -log10(ds[order(ds[, i])[1:cutoff[i]], i])
        }, ds=ds, cutoff=cutoff)
        names(dsf) <- names(cutoff)
        dm <- sqrt(matrix(dsf[[1]]*rep(dsf[[2]], rep(length(dsf[[1]]), length(dsf[[2]]))), length(dsf[[1]]), length(dsf[[2]]), dimnames=list(names(dsf[[1]]), names(dsf[[2]]))))
    }
    ddtmp <- lapply(drugsig, function(drugsig, dm, nn, ws) {
        tmp <- signatureDistance(cbind(filterColMatrix(drugsig, match(rownames(dm), colnames(drugsig))), filterColMatrix(drugsig, match(colnames(dm), colnames(drugsig)))), nn=nn, ws=ws, scale.=F, two.tails=TRUE)
        cortest(scale(tmp)[1:nrow(dm), ][, (nrow(dm)+1):sum(dim(dm))], nrow(drugsig))$z
    }, dm=dm, nn=nn, ws=ws)
    ddtmp1 <- sapply(ddtmp, as.vector)
    ddtmp1 <- apply(ddtmp1, 1, function(x, ints) {
        weighted.mean(abs(x), 1/abs(x)^ints, na.rm=T)
    }, ints=ints)
    dd <- matrix(ddtmp1, nrow(ddtmp[[1]]), ncol(ddtmp[[1]]), dimnames=list(rownames(ddtmp[[1]]), colnames(ddtmp[[1]])))
    dd <- dd[!is.na(rownames(dd)), ][, !is.na(colnames(dd))]
    rm(ddtmp)
    cname <- NULL
    rn <- rownames(dd)[-1]
    for (i in colnames(dd)[1:(ncol(dd)-1)]) {
        cname <- rbind(cname, cbind(rn, rep(i, length(rn))))
        rn <- rn[-1]
    }
    switch(method,
    orthogonal = {
        if (is.null(scc)) scc <- max(abs(dd[upper.tri(dd)]))/ds1
        dd <- (-log10(pnorm(abs(dd)/scc, lower.tail=F)))
        syestim <- dm/dd
    },
    complemental = {
        isig <- rowMeans(sapply(drugsig, function(drugsig, dm, score, phsig, nn, ws, absolute, dnes) {
            dsig <- filterColMatrix(drugsig, match(rownames(dm), colnames(drugsig)))
            d1 <- dsig[, rep(1:ncol(dsig), rep(ncol(dsig), ncol(dsig)))]
            d2 <- dsig[, rep(1:ncol(dsig), ncol(dsig))]
            d1sc <- t(t((abs(d1)/max(abs(d1)))^score) * dnes[match(colnames(d1), names(dnes))])
            d2sc <- t(t((abs(d2)/max(abs(d2)))^score) * dnes[match(colnames(d2), names(dnes))])
            isig <- (d1 * d1sc + d2 * d2sc)/(d1sc+d2sc)
            tmp <- signatureDistance(cbind(-phsig, isig), nn=nn, ws=ws, scale.=F, two.tails=!absolute)
            return(cortest(scale(tmp)[, -1][1, ], nrow(isig))$z)
        }, dm=dm, score=score[1], phsig=phsig[, 1], nn=nn, ws=ws, absolute=absolute, dnes=(abs(dnes[, 1])/max(abs(dnes[, 1])))^score[2]))
        dnes1 <- dnes[match(rownames(dm), rownames(dnes)), 1]
        d1 <- dnes1[rep(1:length(dnes1), rep(length(dnes1), length(dnes1)))]
        d2 <- dnes1[rep(1:length(dnes1), length(dnes1))]
        dmax <- apply(cbind(d1, d2), 1, max)
        scs <- dsf[[1]][match(rownames(dm), names(dsf[[1]]))]
        scs <- cbind(scs[rep(1:length(scs), rep(length(scs), length(scs)))], scs[rep(1:length(scs), length(scs))])
        scs <- matrix(apply(scs, 1, max), length(dsf[[1]]), length(dsf[[1]]))/max(scs)
        syestim <- matrix((isig-dmax)*scs, nrow(dm), ncol(dm))
        if (length(which(syestim>0))>0) {
            syestim <- syestim*(syestim>0) + syestim/max(abs(syestim))*max(syestim)*(syestim<0)
        }
        colnames(syestim) <- rownames(syestim) <- rownames(dm)
    })
    diag(syestim) <- 0
    ortholist <- dd[lower.tri(dd)]
    sylist <- syestim[lower.tri(syestim)]
    names(sylist) <- names(ortholist) <- paste(cname[, 1], cname[, 2], sep=" x ")
    res <- list(phdrugs=sapply(dsf, function(x) x), actmatrix=dm, orthomatrix=dd, symatrix=syestim, orthodrugs=ortholist[order(ortholist, decreasing=T)], sydrugs=sylist[order(sylist, decreasing=T)], param=list(nn=nn, absolute=absolute, cutoff=cutoff, method=method, scc=scc))
    class(res) <- "phenotypeSynergy"
    return(res)
}

#' Plot syngen results
#' 
#' This function generates a graphical output of a phenotypeSynergy object
#' 
#' @param x Object of class phenotypeSynergy
#' @param marg Number indicating the figure margins in inches
#' @param gama Vector of 2 components indicating the gama transformation for the response and synergy heatmap
#' @param line Obset for the axis labels
#' @param annot Optional named vector containing the annotation table for labels
#' @param ... Additional arguments to pass to the plot generic function
#' @return Nothing, a plot is generated in the default output device
#' @method plot phenotypeSynergy
#' @S3method plot phenotypeSynergy
#' @seealso \code{\link{phenoDrug}}
#' @examples
#' data(dream6h)
#' sgr <- phenoDrug(toxicly3, dream6h, nn=50, cutoff=ncol(dream6h), method="complemental", score=0)
#' plot(sgr)
plot.phenotypeSynergy <- function(x, marg=NULL, gama=c(2, 2), line=5, annot=NULL, ...) {
    if (length(gama)==1) gama <- rep(gama, 2)
    if (is.null(marg)) marg <- dev.size("in")[2]/3/max(par("mfrow"))
    if (length(marg)==1) marg <- rep(marg, 2)
    par(mai=c(.1, marg[1], marg[2], .1))
    toad <- list(x$phdrugs[match(rownames(x$symatrix), rownames(x$phdrugs)), 1], x$phdrugs[match(colnames(x$symatrix), rownames(x$phdrugs)), 2])
    toad <- lapply(toad, function(x, mm, gama) -((abs(x)/mm)^gama)*sign(x), mm=max(abs(unlist(toad, use.names=F))), gama=gama[1])
    sytmp <- abs(x$symatrix/max(abs(x$symatrix)))^gama[2]*sign(x$symatrix)
    if (all(is.na(sytmp))) sytmp[is.na(sytmp)] <- 0
    tmp <- rbind(toad[[2]], sytmp)
    tmp <- cbind(c(0, toad[[1]]), tmp)
    plothm(tmp, ...)
    if (!is.null(annot)) {
        rownames(x$symatrix) <- annot[match(rownames(x$symatrix), names(annot))]
        colnames(x$symatrix) <- annot[match(colnames(x$symatrix), names(annot))]
    }
    axis(2, nrow(x$symatrix):1, rownames(x$symatrix), tick=F, las=2, line=-.5, ...)
    axis(3, (1:ncol(x$symatrix))+1, colnames(x$symatrix), tick=F, las=2, line=-.5, ...)
    if (!is.null(colnames(x$phdrugs))) {
        axis(2, nrow(x$symatrix)/2, colnames(x$phdrugs)[1], las=0, tick=F, line=line)
        axis(3, ncol(x$symatrix)/2, colnames(x$phdrugs)[2], las=0, tick=F, line=line)
    }
    abline(v=1.5, h=nrow(x$symatrix)+.5, lwd=2)
}

#' Print syngen results
#' 
#' This function summarize the infor contained in a S3 object of class phenotypeSynergy
#' 
#' @param x S3 object of class phenotypeSynergy
#' @param ... Additional arguments to pass to the print generic function`
#' @return Summary information about the \code{x} object
#' @method print phenotypeSynergy
#' @S3method print phenotypeSynergy
#' @examples
#' data(dream6h)
#' sgr <- phenoDrug(toxicly3, dream6h, nn=50, cutoff=ncol(dream6h), method="complemental", score=0)
#' print(sgr)

print.phenotypeSynergy <- function(x, ...) {
    cat("Object of class phenotypeSynergy with\n", length(x$phdrugs), " drug scores\n", length(x$sydrugs), " synergistic drug pair scores\n")
}

#' Integration of synergy results from multiple runs
#' 
#' This function integrates multiple runs of phenoDrugs stored in a list object
#' 
#' @param x List object containing the phenotypeSynergy objects
#' @param ex Number indicating the exponent for the weights when integrating the synergy score. Negative values will result in taiking the maximum value for the synergy score.
#' @param norm Logical, whether the values should be normalized
#' @return A phenotypeSynergy object
#' @export
phenoDrug.integ <- function(x, ex=0, norm=F) {
    drugs <- unique(unlist(lapply(x, function(x) rownames(x$phdrugs)), use.names=F))
    tmp <- x[[1]]
    tmp$phdrugs <- matrix(rep(rowMeans(sapply(x, function(x, drugs) x$phdrugs[match(drugs, rownames(x$phdrugs)), 1], drugs=drugs), na.rm=T), 2), length(drugs), 2, dimnames=list(drugs, NULL))
    tmp$phdrugs <- tmp$phdrugs[order(tmp$phdrugs[, 1], decreasing=T), ]
    drugs <- rownames(tmp$phdrugs)
    if (ex<0) {
        tmp$symatrix <- matrix(apply(sapply(x, function(x, drugs, norm) {
            tmp <- as.vector(x$symatrix[match(drugs, rownames(x$symatrix)), ][, match(drugs, colnames(x$symatrix))])
            if (norm) return(tmp/max(abs(tmp), na.rm=T))
            tmp[!is.finite(tmp)] <- 0
        return(tmp)
        }, drugs=drugs, norm=norm), 1, max, na.rm=T), length(drugs), length(drugs), dimnames=list(drugs, drugs))
    }
    else {
        tmp1 <- sapply(x, function(x, drugs, norm, ex) {
            tmp <- as.vector(x$symatrix[match(drugs, rownames(x$symatrix)), ][, match(drugs, colnames(x$symatrix))])
            if (norm) return(tmp/max(abs(tmp), na.rm=T))
            return(tmp)
        }, drugs=drugs, norm=norm, ex=ex)
        tmp1 <- tmp1*abs(tmp1)^ex/rowSums(abs(tmp1)^ex, na.rm=T)
        tmp$symatrix <- matrix(rowSums(tmp1, na.rm=T), length(drugs), length(drugs), dimnames=list(drugs, drugs))
    }
    tmp$orthomatrix <- matrix(rowMeans(sapply(x, function(x, drugs) as.vector(x$orthomatrix[match(drugs, rownames(x$orthomatrix)), ][, match(drugs, colnames(x$orthomatrix))]), drugs=drugs), na.rm=T), length(drugs), length(drugs), dimnames=list(drugs, drugs))
    cname <- NULL
    rn <- rownames(tmp$symatrix)[-1]
    for (i in colnames(tmp$symatrix)[1:(ncol(tmp$symatrix)-1)]) {
        cname <- rbind(cname, cbind(rn, rep(i, length(rn))))
        rn <- rn[-1]
    }
    ortholist <- tmp$orthomatrix[lower.tri(tmp$orthomatrix)]
    sylist <- tmp$symatrix[lower.tri(tmp$symatrix)]
    names(sylist) <- names(ortholist) <- paste(cname[, 1], cname[, 2], sep=" x ")
    tmp$orthodrugs <- ortholist[order(ortholist, decreasing=T)]
    tmp$sydrugs <- sylist[order(sylist, decreasing=T)]
    return(tmp)
}
