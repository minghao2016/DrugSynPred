Format of drug_synergy_data_IC20.txt
Cmpd A: Drug1
Cmpd B: Drug2
Excess over Bliss: Excess over Bliss score; 
positive EOB is synergistic and negative EOB is antagonist.
SEM: Standard error of the mean
